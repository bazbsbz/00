function isNumeric(a) {
    for (var b = "0123456789".split(""), d = !1, c = 0; c < b.length; c++)
        if (b[c] === a) {
            d = !0;
            break
        } return d
}

function needHelp(a) {
    $(".faqquestion").click(function(b) {
        $(this).parent().hasClass("viewall") || ($(this).siblings(".faqanswer").slideToggle("fast", function() {
            $(this).parent().hasClass("active") ? $(this).parent().removeClass("active") : $(this).parent().addClass("active")
        }), b.preventDefault(), void 0 != a && null != a && a())
    })
}

function isSpecialChar(a, b) {
    var d = "`~,\\/.!@#$%^><?&*-_+=)([]\"';:{}|".split(""),
        c = !1;
    b || d.push(" ");
    for (var g = 0; g < d.length; g++)
        if (d[g] === a) {
            c = !0;
            break
        } return c
}

function validateIE7(a, b) {
    var d = !1,
        c = !1,
        g = !1,
        f = !1;
    8 <= a.length && 15 >= a.length && (g = !0);
    for (var e = 0; e < a.length; e++) isNumeric(a.charAt(e)) ? d = !0 : 65 < a.charAt(e).charCodeAt(0) && 90 > a.charAt(e).charCodeAt(0) || 97 < a.charAt(e).charCodeAt(0) && 122 > a.charAt(e).charCodeAt(0) ? c = !0 : isSpecialChar(a.charAt(e), b) && (f = !0);
    e = !1;
    g && d && c && !f && (e = !0);
    return e
}

function setFieldState(a, b) {
    b ? ($(a).removeAttr("disabled"), $(a).removeClass("inactive")) : ($(a).attr("disabled", "disabled"), $(a).addClass("inactive"))
}

function hasErrors(a, b, d) {
    var c = !1;
    a = getBasicFieldErrorMessages(2, 35, $(a).val(), b, d);
    null != a && 0 < a.length && (c = !0);
    setFieldState(!c);
    return c
}

function getValidateMessageListCheckSpaces(a, b, d, c, g) {
    var f = "",
        e = getBasicFieldSuccessMessages(b, d, $(a).val(), c, g);
    if (null != e && 0 < e.length)
        for (i = 0; i < e.length; i++) f += "<li class='ok'>" + e[i] + "</li>";
    a = getBasicFieldErrorMessages(b, d, $(a).val(), c, g);
    if (null != a && 0 < a.length)
        for (i = 0; i < a.length; i++) f += "<li class='error'>" + a[i] + "</li>";
    return f
}

function getValidateMessageList(a, b, d, c) {
    return getValidateMessageListCheckSpaces(a, b, d, c, !1)
}

function getBasicFieldErrorMessages(a, b, d, c, g) {
    c = [];
    var f = !1;
    (d.length < a || d.length > b) && c.push("Is between " + a + "-" + b + " characters");
    for (a = 0; a < d.length; a++) isSpecialChar(d.charAt(a), g) && (f = !0);
    f && c.push("Contains only letters and numbers");
    return c
}

function getBasicFieldSuccessMessages(a, b, d, c, g) {
    c = [];
    var f = !1;
    d.length >= a && d.length <= b && c.push("Is between " + a + "-" + b + " characters");
    for (a = 0; a < d.length; a++) isSpecialChar(d.charAt(a), g) && (f = !0);
    f || c.push("Contains only letters and numbers");
    return c
}

function isIE7() {
    var a = !1;
    if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
        var b = new Number(RegExp.$1);
        if (7 == b || 6 == b) a = !0
    }
    return a
}

function isUnsupported() {
    var a = !1;
    /MSIE (\d+\.\d+);/.test(navigator.userAgent) && 8 > new Number(RegExp.$1) && (a = !0);
    return a
}

function setupToolTip(a, b) {
    $(a).tooltip({
        items: "[tooltip-hint]",
        hide: {
            effect: "false",
            delay: 2500
        },
        position: {
            my: "left+25 top",
            at: "right top-10",
            using: function(a, b) {
                $(this).css(a);
                $("<div>").addClass("arrow_left").addClass(b.vertical).addClass(b.horizontal).prependTo(this)
            }
        },
        content: function() {
            var a = $(this);
            if (a.is("[tooltip-hint]")) return a.text(), b
        }
    })
}

function setupNonStickyToolTip(a, b) {
    $(a).tooltip({
        items: "[tooltip-hint]",
        hide: {
            effect: "false"
        },
        position: {
            my: "left+25 top-10",
            at: "right top",
            using: function(a, b) {
                $(this).css(a);
                $("<div>").addClass("arrow_left").addClass(b.vertical).addClass(b.horizontal).prependTo(this)
            }
        },
        content: function() {
            var a = $(this);
            if (a.is("[tooltip-hint]")) return a.text(), b
        }
    })
}

function initPasswordToolTip(a, b) {
    $(a).tooltip({
        items: "[data-hint]",
        position: {
            my: "left+25 top",
            at: "right top",
            using: function(a, b) {
                $(this).css(a);
                $("<div>").addClass("arrow_left").addClass(b.vertical).addClass(b.horizontal).prependTo(this)
            }
        },
        content: function() {
            var a = $(this);
            if (a.is("[data-hint]")) return a.text(), b
        }
    })
}

function initPasswordCapsLock() {
    $("input[type='password']").capslock({
        caps_lock_on: function() {
            0 == $("#capson").length && $("#mainhintlist").append("<li id='capson'>**Your CAPS LOCK is on**</li>")
        },
        caps_lock_off: function() {
            $("#capson").remove()
        },
        caps_lock_undetermined: function() {}
    })
}

function validatePasswordRules(a) {
    var b = [];
    /[0-9]/.test($(a).val()) || b.push("Includes at least one number");
    /[A-Za-z]/.test($(a).val()) || b.push("Includes at least one letter");
    (8 > $.trim($(a).val()).length || 15 < $.trim($(a).val()).length) && b.push("Is between 8-15 characters");
    isIE7() ? validateIE7($(a).val(), !1) || b.push("Contains only letters and numbers") : /^(?=.*[A-Za-z])(?!.*[`~,\\//\.!@#$%\>\<\?^&\*\-_+=\)\(])(?=.*[0-9])\S{8,15}$/.test($(a).val()) || b.push("Contains only letters and numbers");
    return b
}

function validateField(a, b, d, c) {
    c = !0;
    validateFieldIE7(a, b, $(d).val()) || (c = !1);
    return c
}

function isEmpty(a) {
    return 0 == $.trim(a).length
}

function validateGoodPasswordRules(a) {
    var b = [];
    /[0-9]/.test($(a).val()) && b.push("Includes at least one number");
    /[A-Za-z]/.test($(a).val()) && b.push("Includes at least one letter");
    8 <= $.trim($(a).val()).length && 15 >= $.trim($(a).val()).length && b.push("Is between 8-15 characters");
    isIE7() ? validateIE7($(a).val(), !1) && b.push("Contains only letters and numbers") : /^(?=.*[A-Za-z])(?!.*[`~,\\//\.!@#$%\>\<\?^&\*\-_+=\)\(])(?=.*[0-9])\S{8,15}$/.test($(a).val()) && b.push("Contains only letters and numbers");
    return b
};